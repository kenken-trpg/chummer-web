Chummer 5.222.0 / Life Modules

1. Chummerを終了し、settings/内のXMLをChummer本体のsettingsフォルダーへコピーしてください。
2. Chummerを起動し、全体設定でLife Modulesを有効にしてください（試験機能です）。
3. character.chum5を開いてください。作成方式はLifeModule、設定名はChummer Web Life Modulesです。
4. Chummerで保存する場合は別名保存し、アプリのJSONバックアップも保管してください。
Chummerの再保存ではアプリ固有の選択・超過移し替え履歴が消えるため、アプリへの再取り込みはできません。
カスタムデータを使用している場合は、同じデータをChummerにもインストールしてください。

Close Chummer, copy the XML under settings/ into Chummer's settings directory,
then enable Life Modules in global options and open character.chum5.
Use Save As and keep the web app's JSON backup. Desktop resaves lose the
web app's module choices and overflow transfer history and cannot be re-imported.
